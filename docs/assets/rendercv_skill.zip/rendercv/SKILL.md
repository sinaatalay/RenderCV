---
name: rendercv
description: >-
  Create professional CVs and resumes with perfect typography using RenderCV
  (v3.0.0). Users write content in YAML, and RenderCV produces
  publication-quality PDFs via Typst typesetting. 9
  built-in designs, customized in a small Typst file (`design.typ`): colors,
  fonts, margins, spacing, section title styles, entry layouts, and more. Custom
  entry types in `entries.typ`. Any language supported (22
  built-in, or define your own). Outputs PDF, PNG, HTML, and Markdown. Use when
  the user wants to create, edit, customize, or render a CV or resume.
---

## Quick Start

**Built-in designs:** `classic`, `moderncv`, `sb2nov`, `engineeringresumes`, `engineeringclassic`, `harvard`, `ink`, `ember`, `opal`
**Built-in locales:** `arabic`, `danish`, `dutch`, `english`, `french`, `german`, `hebrew`, `hindi`, `hungarian`, `indonesian`, `italian`, `japanese`, `korean`, `mandarin_chinese`, `norwegian_bokmål`, `norwegian_nynorsk`, `persian`, `portuguese`, `russian`, `spanish`, `turkish`, `vietnamese`

```bash
# Install RenderCV
uv tool install "rendercv[full]"

# Create a starter YAML file (optionally with a design.typ and an entries.typ)
rendercv new "John Doe"
rendercv new "John Doe" --design moderncv --locale german --entries

# Render to PDF (also generates Typst, Markdown, HTML, PNG by default)
rendercv render John_Doe_CV.yaml

# Watch mode: auto-re-render whenever the YAML file, design.typ, or entries.typ changes
rendercv render John_Doe_CV.yaml --watch

# Render only PNG (useful for previewing or checking page count)
rendercv render John_Doe_CV.yaml --dont-generate-pdf --dont-generate-html --dont-generate-markdown

# Override fields from the CLI without editing the YAML
rendercv render John_Doe_CV.yaml --cv.name "Jane Doe" --locale.language "german"

# Upgrade a RenderCV 2 file (moves its `design:` field into design.typ)
rendercv migrate John_Doe_CV.yaml
```

## A CV Is Up to Three Files

```
John_Doe_CV.yaml   # Content (cv), language (locale), settings. Any file name.
design.typ         # Optional: how it looks. Default: the classic design.
entries.typ        # Optional: which entry types exist. Default: the standard ones.
```

`design.typ` and `entries.typ` next to the YAML file are used automatically. Other files can be chosen with `rendercv render --design FILE.typ --entries FILE.typ` or with `settings.render_command.design` / `settings.render_command.entries` in the YAML.

**IMPORTANT: RenderCV 3 has no `design:` field in the YAML.** A YAML file with a `design:` key is an error. All visual customization goes into `design.typ`. Never write `design: theme: ...`.

## YAML Structure

```yaml
cv:         # Your content: name, contact info, and all sections
locale:     # Language: month names, "present", phrases, direction
settings:   # Behavior: output paths, bold keywords, current date, design/entries files
```

Only `cv` is required. The YAML maps to these Pydantic models (validators omitted):

```python
class RenderCVModel(BaseModelWithoutExtraKeys):
    cv: Cv = pydantic.Field(default_factory=Cv, description='The content of the CV.')
    locale: Locale = pydantic.Field(default_factory=default_locale, description='The language of the CV: its words and date formats.')
    settings: Settings = pydantic.Field(default_factory=Settings, description='The settings of the RenderCV.')

```

```python
class Cv(BaseModelWithoutExtraKeys):
    name: MarkdownText | None = pydantic.Field(default=None, examples=['John Doe', 'Jane Smith'])
    headline: MarkdownText | None = pydantic.Field(default=None, examples=['Software Engineer', 'Data Scientist', 'Product Manager'])
    location: MarkdownText | None = pydantic.Field(default=None, examples=['New York, NY', 'London, UK', 'Istanbul, Türkiye'])
    email: pydantic.EmailStr | list[pydantic.EmailStr] | None = pydantic.Field(default=None, description='You can provide multiple emails as a list.', examples=['john.doe@example.com', ['john.doe.1@example.com', 'john.doe.2@example.com']])
    photo: ExistingPathRelativeToInput | pydantic.HttpUrl | None = pydantic.Field(default=None, description='Photo file path (relative to the YAML file) or a URL.', examples=['photo.jpg', 'images/profile.png', 'https://example.com/photo.jpg'])
    phone: PhoneNumber | list[PhoneNumber] | None = pydantic.Field(default=None, examples=['+1-234-567-8900', ['+1-234-567-8900', '+44 20 1234 5678']])
    website: Url | list[Url] | None = pydantic.Field(default=None, description='You can provide multiple URLs as a list.', examples=['https://johndoe.com', ['https://johndoe.com', 'https://www.janesmith.dev']])
    social_networks: list[SocialNetwork] | None = pydantic.Field(default=None)
    custom_connections: list[CustomConnection] | None = pydantic.Field(default=None, examples=[[{'placeholder': 'Book a call', 'url': 'https://cal.com/johndoe', 'fontawesome_icon': 'calendar-days'}]])
    sections: Sections | None = pydantic.Field(default=None)

```

```python
class SocialNetwork(BaseModelWithoutExtraKeys):
    network: str = pydantic.Field(description='The social network.')
    username: str = pydantic.Field(description='Your username on the network.', examples=['johndoe', '@johndoe@mastodon.social', '12345/johndoe'])

```

Available social networks: `Bluesky`, `GitHub`, `GitLab`, `Google Scholar`, `IMDB`, `Instagram`, `Leetcode`, `LinkedIn`, `Mastodon`, `ORCID`, `Reddit`, `ResearchGate`, `StackOverflow`, `Telegram`, `WhatsApp`, `X`, `YouTube`. For anything else, use `custom_connections`:

```python
class CustomConnection(BaseModelWithoutExtraKeys):
    fontawesome_icon: str
    placeholder: str
    url: pydantic.HttpUrl | None = None

```

```python
class Phrases(BaseModelWithoutExtraKeys):
    degree_with_area: str = pydantic.Field(examples=['#degree in #area', '#degree en #area'])

type MonthNames = Annotated[list[str], at.Len(min_length=12, max_length=12)]

class Locale(BaseModelWithoutExtraKeys):
    language: str = pydantic.Field(default='english')
    iso_code: str = pydantic.Field(examples=['en', 'de', 'tr'])
    direction: Literal['ltr', 'rtl'] = pydantic.Field(default='ltr', description='The writing direction: `ltr` (left to right) or `rtl`.')
    last_updated: str = pydantic.Field(description='Translation of "Last updated in".')
    present: str = pydantic.Field(description='Translation of "present".')
    month: str = pydantic.Field(description='Translation of "month".')
    months: str = pydantic.Field(description='Translation of "months".')
    year: str = pydantic.Field(description='Translation of "year".')
    years: str = pydantic.Field(description='Translation of "years".')
    phrases: Phrases
    month_abbreviations: MonthNames = pydantic.Field(description='Month abbreviations, January to December.')
    month_names: MonthNames = pydantic.Field(description='Month names, January to December.')

```

```python
class Settings(BaseModelWithoutExtraKeys):
    current_date: datetime.date | Literal['today'] = pydantic.Field(default='today')
    render_command: RenderCommand = pydantic.Field(default_factory=RenderCommand)
    bold_keywords: list[str] = pydantic.Field(default=[], description='Keywords to automatically bold in the output.')
    pdf_title: str = pydantic.Field(default='NAME - CV')

type TypstFilePath = Annotated[ExistingPathRelativeToInput, pydantic.AfterValidator(check_typst_file)]

class RenderCommand(BaseModelWithoutExtraKeys):
    output_folder: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('rendercv_output'))
    design: TypstFilePath | None = pydantic.Field(default=None)
    entries: TypstFilePath | None = pydantic.Field(default=None)
    locale: ExistingPathRelativeToInput | None = pydantic.Field(default=None, description='Path to a YAML file containing the `locale` field.')
    typst_path: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('OUTPUT_FOLDER/NAME_IN_SNAKE_CASE_CV.typ'))
    pdf_path: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('OUTPUT_FOLDER/NAME_IN_SNAKE_CASE_CV.pdf'))
    markdown_path: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('OUTPUT_FOLDER/NAME_IN_SNAKE_CASE_CV.md'))
    html_path: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('OUTPUT_FOLDER/NAME_IN_SNAKE_CASE_CV.html'))
    png_path: PlannedPathRelativeToInput = pydantic.Field(default=pathlib.Path('OUTPUT_FOLDER/NAME_IN_SNAKE_CASE_CV.png'))
    dont_generate_markdown: bool = pydantic.Field(default=False, description='Skip Markdown generation. The default value is `false`.')
    dont_generate_html: bool = pydantic.Field(default=False, description='Skip HTML generation. The default value is `false`.')
    dont_generate_typst: bool = pydantic.Field(default=False)
    dont_generate_pdf: bool = pydantic.Field(default=False, description='Skip PDF generation. The default value is `false`.')
    dont_generate_png: bool = pydantic.Field(default=False, description='Skip PNG generation. The default value is `false`.')

```

## Sections and Entry Types

`cv.sections` maps section titles (any text; `snake_case` keys become Title Case) to lists of entries. A section can also be a mapping of subsection titles to lists of entries.

The entry type of each entry is detected from its fields: an entry fits a type if it has all the type's required fields and no fields the type doesn't have. An entry that is plain text is a `paragraph`. If several types fit, add `type: <name>` to the entry. **Unknown fields are errors**, so never invent fields; to add a field, declare an entry type in `entries.typ` (see below).

**Standard entry types:**

| Entry type | Required fields | Optional fields | Use |
|---|---|---|---|
| `normal` | `name` (markdown) | `date` (date or text), `start_date` (date), `end_date` (date), `location` (markdown), `summary` (markdown), `highlights` (bullets) | A general entry with a name: a project, an award, an activity. |
| `experience` | `company` (markdown), `position` (markdown) | `date` (date or text), `start_date` (date), `end_date` (date), `location` (markdown), `summary` (markdown), `highlights` (bullets) | A position at a company or organization. |
| `education` | `institution` (markdown), `area` (markdown) | `degree` (markdown), `date` (date or text), `start_date` (date), `end_date` (date), `location` (markdown), `summary` (markdown), `highlights` (bullets) | A degree, diploma, or other education. |
| `publication` | `title` (markdown), `authors` (list of markdown) | `summary` (markdown), `doi` (text), `url` (url), `journal` (markdown), `date` (date or text) | A paper, article, book, or other publication. |
| `one_line` | `label` (markdown), `details` (markdown) | — | A label and its details on one line, like "Languages: English, Turkish". |
| `bullet` | `bullet` (markdown) | — | One bullet point. |
| `numbered` | `number` (markdown) | — | One item of a numbered list: 1, 2, 3, … |
| `reversed_numbered` | `reversed_number` (markdown) | — | One item of a list numbered backwards, so the latest item has the highest number. |
| `paragraph` | `text` (markdown) | — | A paragraph of text. An entry written as plain text is a paragraph. |

Dates: `start_date`/`end_date` take `YYYY-MM-DD`, `YYYY-MM`, or `YYYY`; `end_date` can be `present` (omitting it also means ongoing). A single `date` also accepts free text like `"Fall 2023"`. Use either `date` or `start_date`/`end_date`.

```yaml
cv:
  sections:
    experience:              # experience (company + position)
      - company: Google
        position: Engineer
        start_date: 2020-01
        highlights:
          - Did something impactful
    skills:                  # one_line (label + details)
      - label: Languages
        details: Python, C++
    about_me:                # paragraph (plain text)
      - This is a free-form paragraph about me.
    projects:
      Open source:           # subsection
        - name: FlashInfer   # normal (name)
          date: 2023
```

## Text

- All text fields support inline Markdown: `**bold**`, `*italic*`, `[link text](url)`, `` `code` ``, and `$$math$$` (Typst math syntax). Block-level Markdown (headings, lists) is not supported.
- Everything else is printed literally: `$`, `#`, `@`, `<` need no escaping.
- Raw Typst markup: tag the value with `!typst`, e.g. `- !typst "Showed that $f(x) = x^2$ is a #emph[parabola]."`
- Nested bullets in `highlights`: put ` - ` inside a bullet, or indent the sub-bullets on the next lines (YAML joins them):

    ```yaml
    highlights:
      - Main bullet point
        - Sub-bullet 1
        - Sub-bullet 2
    ```

- Publication `authors`: wrap the CV owner's name in `**double asterisks**` to bold it.

### YAML quoting

**ALWAYS quote string values that contain a colon followed by a space (`: `) or ` #`.** This is the most common cause of invalid YAML:

```yaml
# WRONG — colon breaks YAML parsing, and " #1" becomes a comment:
- title: Catalytic Mechanisms: A New Approach
  highlights:
    - Closed issue #1 in the tracker

# RIGHT — wrap in double quotes:
- title: "Catalytic Mechanisms: A New Approach"
  highlights:
    - "Closed issue #1 in the tracker"
```

### Phone numbers

Phone numbers MUST include the country code (`"+15551234567"`). Never invent a phone number — only include one if the user provides it. If the user provides a local number without country code, ask which country, or omit the phone field.

## Design (`design.typ`)

`design.typ` must define `design`. The simplest one picks a built-in design and changes options:

```typst
// The design of your CV. To use another design, replace `classic` with one of:
// classic, moderncv, sb2nov, engineeringresumes, engineeringclassic, harvard, ink, ember, opal.
#import "@preview/rendercv:3.0.0": designs

#let design = designs.classic(
  // Change any option, for example:
  // page: (size: "a4"),
  // colors: (name: rgb("#004f90"), section_titles: rgb("#004f90")),
  // typography: (font_family: "Source Sans 3", font_size: (body: 10pt)),
)

```

All built-in designs share the options below and differ only in their defaults. Options are nested Typst dictionaries that merge key by key, so only changed options are needed. Values are Typst values: lengths `0.7in`/`10pt`/`1.2em`, colors `rgb("#004f90")`/`rgb(0, 79, 144)`, alignments `left`/`center`/`right` (no quotes), text `"a4"` (quoted). A one-element array needs a trailing comma: `("experience",)`. Unknown options and wrong types are errors.

These are all options with the classic design's defaults:

```typst
#let defaults = (
  page: (
    size: "us-letter",
    top_margin: 0.7in,
    bottom_margin: 0.7in,
    left_margin: 0.7in,
    right_margin: 0.7in,
    show_footer: true,
    show_top_note: true,
  ),
  colors: (
    body: rgb(0, 0, 0),
    name: rgb(0, 79, 144),
    headline: rgb(0, 79, 144),
    connections: rgb(0, 79, 144),
    section_titles: rgb(0, 79, 144),
    links: rgb(0, 79, 144),
    footer: rgb(128, 128, 128),
    top_note: rgb(128, 128, 128),
  ),
  typography: (
    line_spacing: 0.6em,
    alignment: "justified",
    date_and_location_column_alignment: right,
    font_family: (
      body: "Source Sans 3",
      name: "Source Sans 3",
      headline: "Source Sans 3",
      connections: "Source Sans 3",
      section_titles: "Source Sans 3",
    ),
    font_size: (
      body: 10pt,
      name: 30pt,
      headline: 10pt,
      connections: 10pt,
      section_titles: 1.4em,
    ),
    small_caps: (name: false, headline: false, connections: false, section_titles: false),
    bold: (name: true, headline: false, connections: false, section_titles: true),
  ),
  links: (underline: false, show_external_link_icon: false),
  header: (
    alignment: center,
    photo_width: 3.5cm,
    photo_position: "left",
    photo_space_left: 0.4cm,
    photo_space_right: 0.4cm,
    space_below_name: 0.7cm,
    space_below_headline: 0.7cm,
    space_below_connections: 0.7cm,
    connections: (
      phone_number_format: "national",
      hyperlink: true,
      show_icons: true,
      display_urls_instead_of_usernames: false,
      separator: "",
      space_between_connections: 0.5cm,
    ),
  ),
  section_titles: (
    type: "with_partial_line",
    line_thickness: 0.5pt,
    space_above: 0.5cm,
    space_below: 0.3cm,
  ),
  sections: (
    allow_page_break: true,
    space_between_regular_entries: 1.2em,
    space_between_text_based_entries: 0.3em,
    show_time_spans_in: ("experience",),
  ),
  entries: (
    date_and_location_width: 4.15cm,
    side_space: 0.2cm,
    space_between_columns: 0.1cm,
    allow_page_break: false,
    short_second_row: true,
    degree_width: 1cm,
    summary: (space_above: 0cm, space_left: 0cm),
    highlights: (
      bullet: "•",
      nested_bullet: "•",
      space_left: 0.15cm,
      space_above: 0cm,
      space_between_items: 0cm,
      space_between_bullet_and_text: 0.5em,
    ),
  ),
  templates: (
    /// `(info) => content`: the footer of every page.
    footer: info => context emph[#info.name -- #here().page()\/#counter(page).final().first()],
    /// `(info) => content`: the note at the top of the first page.
    top_note: info => emph[#info.locale.last_updated #(info.format-date)(info.current-date)],
    /// `(date, locale) => content`: how a date with a month is written.
    single_date: month-abbreviation-and-year,
    /// `(start, end) => content`: how a date range is written.
    date_range: (start, end) => [#start – #end],
    /// `(start, end, ctx) => content`: how long something lasted.
    time_span: (start, end, ctx) => format-time-span(start, end, ctx.locale, ctx.settings.current_date),
  ),
)
```

Choices: `page.size` any Typst paper (`"us-letter"`, `"a4"`, ...); `typography.alignment` `"justified"`/`"left"`/`"justified-with-no-hyphenation"`; `typography.font_family` one font name or a dictionary per part; `header.photo_position` `"left"`/`"right"`; `header.connections.phone_number_format` `"national"`/`"international"`/`"e164"`; `section_titles.type` `"with_partial_line"`/`"with_full_line"`/`"without_line"`/`"moderncv"`/`"centered_without_line"`/`"centered_with_partial_line"`/`"centered_with_centered_partial_line"`/`"centered_with_full_line"`; `sections.show_time_spans_in` section keys (lowercase title with underscores).

Example: dark red, A4, 1-inch margins, New Computer Modern:

```typst
#import "@preview/rendercv:3.0.0": designs

#let design = designs.classic(
  page: (size: "a4", top_margin: 1in, bottom_margin: 1in, left_margin: 1in, right_margin: 1in),
  colors: (name: rgb("#8b0000"), section_titles: rgb("#8b0000")),
  typography: (font_family: "New Computer Modern"),
)
```

To change how one entry type looks, replace its look in the design's `entries` (a design is a Typst dictionary):

```typst
#import "@preview/rendercv:3.0.0": designs

#let base = designs.sb2nov()
#let design = base + (
  entries: base.entries + (
    one_line: (it, ctx) => block(below: 0.8em)[#smallcaps(it.label) · #it.details],
  ),
)
```

## Custom Entry Types (`entries.typ`)

`entries.typ` is a Typst module; every entry type it defines or imports is allowed in the YAML. `rendercv new "John Doe" --entries` creates this one:

```typst
// The entry types your CV can use: the standard ones, plus your own.
#import "@preview/rendercv:3.0.0": *

// An example of your own entry type: a talk. In the YAML, an entry with
// `title`, `event`, and `date` is now a talk.
#let talk = entry-type(
  doc: "A talk at a conference or event.",
  fields: (
    title: field("markdown", doc: "The title of the talk."),
    event: field("markdown", doc: "Where the talk was given."),
    date: field("date", doc: "When the talk was given."),
    slides: field("url", optional: true, doc: "A link to the slides."),
  ),
  // Drawn as a normal entry, so every design styles it:
  look: (it, ctx) => as-entry(
    "normal",
    name: [#it.title -- #emph(it.event)],
    date: it.date,
    summary: if it.slides != none [#link(it.slides)[Slides]],
  ),
)

```

Field kinds: `markdown`, `text` (optional `pattern:`), `date` (`allow-text: true` for free text), `url`, `email`, `phone`, `number`, `bool`, `choice` (`choices: (...)`), `list` (`of: "markdown"`), `bullets`, `entries`. `field(kind, optional: true, doc: "...")`. A look `(it, ctx) => ...` returns content or hands over to another type with `as-entry("normal", ...)`, so every design draws it.

To add a field to a standard type, make a new type with the standard fields plus a **required** new field, handing over to the standard type:

```typst
#import "@preview/rendercv:3.0.0": *

#let job = entry-type(
  fields: experience.fields + (tech_stack: field("markdown")),
  look: (it, ctx) => as-entry(
    "experience",
    company: it.company,
    position: it.position,
    date: it.date,
    start_date: it.start_date,
    end_date: it.end_date,
    location: it.location,
    summary: [_Tech stack:_ #it.tech_stack],
    highlights: it.highlights,
  ),
)
```

## Locale

Set `locale.language` to a built-in locale and override any field. For another language, give it any name and provide every field (`iso_code`, `last_updated`, `present`, `month`, `months`, `year`, `years`, `phrases.degree_with_area`, `month_abbreviations`, `month_names`; `direction` defaults to `ltr`). `phrases.degree_with_area` is Typst markup: `"#degree in #area"`.

## CLI Reference

### `rendercv new "Full Name"`

| Option | What it does |
|---|---|
| `--design NAME` | Also create a `design.typ` using this built-in design |
| `--locale LOCALE` | Locale to use (default: `english`) |
| `--entries` | Also create an `entries.typ` with an example custom entry type |

### `rendercv render <input.yaml>`

| Option | Short | What it does |
|---|---|---|
| `--watch` | `-w` | Re-render automatically when an input file changes |
| `--quiet` | `-q` | Suppress all output messages |
| `--design FILE.typ` | `-d` | Use this design file instead of `design.typ` |
| `--entries FILE.typ` | `-e` | Use this entry types file instead of `entries.typ` |
| `--locale-catalog FILE` | `-lc` | Load the `locale` field from a separate YAML file |
| `--settings FILE` | `-s` | Load the `settings` field from a separate YAML file |
| `--output-folder DIR` | `-o` | Custom output directory |

Per-format controls: `--{format}-path PATH` sets a custom output path, `--dont-generate-{format}` skips generation. Formats: `pdf`, `typst`, `markdown`, `html`, `png`. Any YAML field can be overridden with dot notation: `--cv.sections.education.0.institution "MIT"`.

### `rendercv migrate <input.yaml>`

Converts a RenderCV 2 file: moves its `design:` field into `design.typ` and keeps the original as `*.v2.yaml`.

## JSON Schema

For YAML editor autocompletion and validation (standard entry types only):

```yaml
# yaml-language-server: $schema=https://raw.githubusercontent.com/rendercv/rendercv/refs/tags/v3.0.0/schema.json
```

## Complete Example

```yaml
# yaml-language-server: $schema=https://raw.githubusercontent.com/rendercv/rendercv/refs/tags/v3.0.0/schema.json
cv:
  name: "John Doe"
  headline:
  location: San Francisco, CA
  email: john.doe@email.com
  photo:
  phone:
  website: https://rendercv.com/
  social_networks:
    - network: LinkedIn
      username: rendercv
    - network: GitHub
      username: rendercv
  sections:
    Welcome to RenderCV:
      - RenderCV reads a CV written in a YAML file, and generates a PDF with professional typography.
      - Each section title is arbitrary.
    education:
      - institution: Princeton University
        area: Computer Science
        degree: PhD
        date:
        start_date: 2018-09
        end_date: 2023-05
        location: Princeton, NJ
        summary:
        highlights:
          - "Thesis: Efficient Neural Architecture Search for Resource-Constrained Deployment"
          - "Advisor: Prof. Sanjeev Arora"
          - NSF Graduate Research Fellowship, Siebel Scholar (Class of 2022)
      - date:
        start_date: 2014-09
        end_date: 2018-06
        location: Istanbul, Türkiye
        summary:
        highlights:
          - "GPA: 3.97/4.00, Valedictorian"
          - Fulbright Scholarship recipient for Graduate Studies
        institution: Boğaziçi University
        area: Computer Engineering
        degree: BS
    experience:
      - date:
        start_date: 2023-06
        end_date: present
        location: San Francisco, CA
        summary:
        highlights:
          - Built foundation model infrastructure serving 2M+ monthly API requests with 99.97% uptime
          - Raised $18M Series A led by Sequoia Capital, with participation from a16z and Founders Fund
          - Scaled engineering team from 3 to 28 across ML research, platform, and applied AI divisions
          - Developed proprietary inference optimization reducing latency by 73% compared to baseline
        company: Nexus AI
        position: Co-Founder & CTO
      - date:
        start_date: 2022-05
        end_date: 2022-08
        location: Santa Clara, CA
        summary:
        highlights:
          - Designed sparse attention mechanism reducing transformer memory footprint by 4.2x
          - Co-authored paper accepted at NeurIPS 2022 (spotlight presentation, top 5% of submissions)
        company: NVIDIA Research
        position: Research Intern
    projects:
      - date:
        start_date: 2023-01
        end_date: present
        location:
        summary: Open-source library for high-performance LLM inference kernels
        highlights:
          - Achieved 2.8x speedup over baseline attention implementations on A100 GPUs
          - Adopted by 3 major AI labs, 8,500+ GitHub stars, 200+ contributors
        name: "[FlashInfer](https://github.com/)"
      - date: "2021"
        start_date:
        end_date:
        location:
        summary: Automated neural network pruning toolkit with differentiable masks
        highlights:
          - Reduced model size by 90% with less than 1% accuracy degradation on ImageNet
          - Featured in PyTorch ecosystem tools, 4,200+ GitHub stars
        name: "[NeuralPrune](https://github.com/)"
    publications:
      - date: 2023-07
        title: "Sparse Mixture-of-Experts at Scale: Efficient Routing for Trillion-Parameter Models"
        authors:
          - "*John Doe*"
          - Sarah Williams
          - David Park
        doi: 10.1234/neurips.2023.1234
        url:
        journal: NeurIPS 2023
      - date: 2022-12
        title: Neural Architecture Search via Differentiable Pruning
        authors:
          - James Liu
          - "*John Doe*"
        doi: 10.1234/neurips.2022.5678
        url:
        journal: NeurIPS 2022, Spotlight
    selected_honors:
      - bullet: MIT Technology Review 35 Under 35 Innovators (2024)
      - bullet: Forbes 30 Under 30 in Enterprise Technology (2024)
    skills:
      - label: Languages
        details: Python, C++, CUDA, Rust, Julia
      - label: ML Frameworks
        details: PyTorch, JAX, TensorFlow, Triton, ONNX
    patents:
      - number: Adaptive Quantization for Neural Network Inference on Edge Devices (US Patent 11,234,567)
      - number: Dynamic Sparsity Patterns for Efficient Transformer Attention (US Patent 11,345,678)
    invited_talks:
      - reversed_number: Scaling Laws for Efficient Inference — Stanford HAI Symposium (2024)
      - reversed_number: Building AI Infrastructure for the Next Decade — TechCrunch Disrupt (2024)
locale:
  language: english

```
